# gb_sem_ab_testing
Files for seminars